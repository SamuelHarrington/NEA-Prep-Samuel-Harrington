﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class AddPoints : MonoBehaviour {

	public int score;
	public TextMeshPro scoreText;

	void start()
	{
		score = 0;
	}


	void OnTriggerEnter(Collider col)
	{
		if (col.gameObject.tag == "5pt") {
			score += 5;

			scoreText.text = "Score: " + score.ToString ();

			Destroy (col.gameObject);
		}
	}

	void OnCollisionEnter(Collision col)
	{
		if (col.gameObject.tag == "-10pt") {
			score -= 10;

			scoreText.text = "Score: " + score.ToString();

			Destroy (col.gameObject);
		}

	}
}
