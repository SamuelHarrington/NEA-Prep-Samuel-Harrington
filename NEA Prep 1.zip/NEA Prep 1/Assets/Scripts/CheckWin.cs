﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class CheckWin : MonoBehaviour {

	public int gameScore;
	public TextMeshPro timerText;
	
	// Update is called once per frame
	void Update () {
		int x = ((int)(Time.fixedTime%60));
		timerText.text = "Time: " + x.ToString();
		gameScore = GameObject.FindGameObjectWithTag ("Player").GetComponent<AddPoints> ().score;
		if (gameScore > 10) {
			Debug.Log ("Winner!");
		}
		else if (gameScore < 0) {
			Debug.Log ("Loser!");
		}
	}
}
